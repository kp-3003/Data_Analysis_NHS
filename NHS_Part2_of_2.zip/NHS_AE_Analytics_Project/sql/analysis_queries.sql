-- =====================================================================
-- NHS A&E Admissions Warehouse — Analytical SQL Queries
-- Database: nhs_ae.db (SQLite)
-- Star schema: fact_ae_admissions + dim_date, dim_icd10_chapter,
--              dim_admission_method, dim_treatment_function, dim_sex
-- =====================================================================

-- 1. Headline KPIs -----------------------------------------------------
SELECT
    COUNT(*)                                            AS total_admissions,
    ROUND(AVG(AE_Time_Mins), 1)                         AS avg_ae_time_mins,
    ROUND(100.0 * SUM(breach_4hr) / COUNT(*), 1)        AS pct_4hr_breach,
    ROUND(AVG(Length_Of_Stay_Days), 2)                  AS avg_length_of_stay_days,
    ROUND(100.0 * SUM(is_weekend) / COUNT(*), 1)        AS pct_weekend_arrivals
FROM fact_ae_admissions;

-- 2. Monthly admissions trend and breach rate (for line/area chart) ----
SELECT
    arrival_year_month,
    COUNT(*)                                          AS admissions,
    ROUND(100.0 * SUM(breach_4hr) / COUNT(*), 1)      AS pct_4hr_breach,
    ROUND(AVG(AE_Time_Mins), 1)                       AS avg_ae_time_mins
FROM fact_ae_admissions
GROUP BY arrival_year_month
ORDER BY arrival_year_month;

-- 3. Demand by day of week and hour of day (heatmap source) ------------
SELECT
    arrival_dow,
    arrival_dow_num,
    AE_Arrive_HourOfDay,
    COUNT(*) AS admissions
FROM fact_ae_admissions
GROUP BY arrival_dow, arrival_dow_num, AE_Arrive_HourOfDay
ORDER BY arrival_dow_num, AE_Arrive_HourOfDay;

-- 4. Seasonality: admissions by calendar month across all years -------
SELECT
    arrival_month,
    arrival_month_name,
    COUNT(*) AS admissions,
    ROUND(AVG(AE_Time_Mins), 1) AS avg_ae_time_mins
FROM fact_ae_admissions
GROUP BY arrival_month, arrival_month_name
ORDER BY arrival_month;

-- 5. Breach rate and average AE time by age band ------------------------
SELECT
    Age_Band,
    COUNT(*)                                       AS admissions,
    ROUND(AVG(AE_Time_Mins), 1)                    AS avg_ae_time_mins,
    ROUND(100.0 * SUM(breach_4hr) / COUNT(*), 1)   AS pct_4hr_breach,
    ROUND(AVG(Length_Of_Stay_Days), 2)             AS avg_los_days
FROM fact_ae_admissions
GROUP BY Age_Band
ORDER BY Age_Band;

-- 6. Arrival mode vs breach rate and resource burden --------------------
SELECT
    arrival_mode_label,
    COUNT(*)                                       AS admissions,
    ROUND(AVG(AE_Time_Mins), 1)                    AS avg_ae_time_mins,
    ROUND(100.0 * SUM(breach_4hr) / COUNT(*), 1)   AS pct_4hr_breach,
    ROUND(AVG(resource_burden), 2)                 AS avg_resource_burden
FROM fact_ae_admissions
GROUP BY arrival_mode_label;

-- 7. Top clinical chapters (ICD-10) by volume and average AE time -------
SELECT
    icd10_chapter_desc,
    COUNT(*)                                       AS admissions,
    ROUND(AVG(AE_Time_Mins), 1)                    AS avg_ae_time_mins,
    ROUND(100.0 * SUM(breach_4hr) / COUNT(*), 1)   AS pct_4hr_breach
FROM fact_ae_admissions
GROUP BY icd10_chapter_desc
ORDER BY admissions DESC
LIMIT 10;

-- 8. Treatment function (specialty) workload ranking --------------------
SELECT
    treatment_function_desc,
    COUNT(*)                                       AS admissions,
    ROUND(AVG(Length_Of_Stay_Days), 2)             AS avg_los_days
FROM fact_ae_admissions
GROUP BY treatment_function_desc
ORDER BY admissions DESC
LIMIT 10;

-- 9. Deprivation (IMD decile) vs breach rate and long-stay rate ---------
SELECT
    IMD_Decile_From_LSOA,
    COUNT(*)                                             AS admissions,
    ROUND(100.0 * SUM(breach_4hr) / COUNT(*), 1)         AS pct_4hr_breach,
    ROUND(100.0 * SUM(long_stay_flag) / COUNT(*), 1)     AS pct_long_stay
FROM fact_ae_admissions
GROUP BY IMD_Decile_From_LSOA
ORDER BY IMD_Decile_From_LSOA;

-- 10. Investigation burden vs average AE time (drives 4-hr breach) ------
SELECT
    AE_Num_Investigations,
    COUNT(*)                       AS admissions,
    ROUND(AVG(AE_Time_Mins), 1)    AS avg_ae_time_mins
FROM fact_ae_admissions
GROUP BY AE_Num_Investigations
ORDER BY AE_Num_Investigations;

-- 11. Year-on-year admissions growth ------------------------------------
SELECT
    arrival_year,
    COUNT(*) AS admissions,
    ROUND(
      100.0 * (COUNT(*) - LAG(COUNT(*)) OVER (ORDER BY arrival_year))
      / LAG(COUNT(*)) OVER (ORDER BY arrival_year), 1
    ) AS pct_change_yoy
FROM fact_ae_admissions
GROUP BY arrival_year
ORDER BY arrival_year;

-- 12. Night-time (00:00-04:00) vs daytime breach comparison -------------
SELECT
    CASE WHEN AE_Arrive_HourOfDay IN ('01-04','21-24') THEN 'Night (21:00-04:00)'
         ELSE 'Day (04:00-21:00)' END AS time_period,
    COUNT(*)                                       AS admissions,
    ROUND(100.0 * SUM(breach_4hr) / COUNT(*), 1)   AS pct_4hr_breach,
    ROUND(AVG(AE_Time_Mins), 1)                    AS avg_ae_time_mins
FROM fact_ae_admissions
GROUP BY time_period;

-- 13. Distance travelled vs breach outcome (access/equity lens) ---------
SELECT
    CASE
        WHEN Provider_Patient_Distance_Miles < 2 THEN '0-2 miles'
        WHEN Provider_Patient_Distance_Miles < 5 THEN '2-5 miles'
        WHEN Provider_Patient_Distance_Miles < 10 THEN '5-10 miles'
        ELSE '10+ miles'
    END AS distance_band,
    COUNT(*)                                       AS admissions,
    ROUND(100.0 * SUM(breach_4hr) / COUNT(*), 1)   AS pct_4hr_breach
FROM fact_ae_admissions
GROUP BY distance_band
ORDER BY MIN(Provider_Patient_Distance_Miles);

-- 14. Weekday vs weekend operational comparison --------------------------
SELECT
    CASE WHEN is_weekend = 1 THEN 'Weekend' ELSE 'Weekday' END AS day_type,
    COUNT(*)                                       AS admissions,
    ROUND(AVG(AE_Time_Mins), 1)                    AS avg_ae_time_mins,
    ROUND(100.0 * SUM(breach_4hr) / COUNT(*), 1)   AS pct_4hr_breach
FROM fact_ae_admissions
GROUP BY day_type;

-- 15. Admission method mix (planned vs emergency pathways) --------------
SELECT
    admission_method_desc,
    COUNT(*) AS admissions,
    ROUND(100.0 * COUNT(*) / (SELECT COUNT(*) FROM fact_ae_admissions), 1) AS pct_of_total
FROM fact_ae_admissions
GROUP BY admission_method_desc
ORDER BY admissions DESC
LIMIT 10;
