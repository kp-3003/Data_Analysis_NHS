# NHS A&E Warehouse — SQL Query Results

### 1. Headline KPIs -----------------------------------------------------

|   total_admissions |   avg_ae_time_mins |   pct_4hr_breach |   avg_length_of_stay_days |   pct_weekend_arrivals |
|-------------------:|-------------------:|-----------------:|--------------------------:|-----------------------:|
|             326444 |              286.2 |               35 |                      4.35 |                   30.9 |


### 2. Monthly admissions trend and breach rate (for line/area chart) ----

| arrival_year_month   |   admissions |   pct_4hr_breach |   avg_ae_time_mins |
|:---------------------|-------------:|-----------------:|-------------------:|
| 2014-03              |         1797 |             35.7 |              288.7 |
| 2014-04              |         5926 |             36.3 |              289.8 |
| 2014-05              |         6370 |             35.4 |              287.1 |
| 2014-06              |         5942 |             35.5 |              285.6 |
| 2014-07              |         5805 |             35.6 |              286.1 |
| 2014-08              |         5549 |             34.3 |              287.1 |
| 2014-09              |         5843 |             35.3 |              284.4 |
| 2014-10              |         6125 |             34.7 |              285.4 |
| 2014-11              |         6174 |             35   |              287.5 |
| 2014-12              |         5893 |             35.4 |              284.2 |
| 2015-01              |         5690 |             34.1 |              281.8 |
| 2015-02              |         5569 |             34.8 |              287.8 |
| 2015-03              |         6163 |             34.7 |              286.5 |
| 2015-04              |         6040 |             35.2 |              289   |
| 2015-05              |         6383 |             34.1 |              283.4 |
| 2015-06              |         6420 |             35.1 |              288.9 |
| 2015-07              |         6210 |             34.9 |              286   |
| 2015-08              |         5954 |             34.4 |              283.7 |
| 2015-09              |         6166 |             35.3 |              287.7 |
| 2015-10              |         6396 |             34.4 |              285.9 |
| 2015-11              |         6468 |             34.2 |              283   |
| 2015-12              |         6140 |             35.5 |              290.3 |
| 2016-01              |         6606 |             34.4 |              286.1 |
| 2016-02              |         6591 |             35.4 |              287.5 |
| 2016-03              |         8190 |             36   |              287.8 |
| 2016-04              |         7308 |             35.3 |              285.9 |
| 2016-05              |         7751 |             34.8 |              287.8 |
| 2016-06              |         7483 |             35.8 |              290.2 |
| 2016-07              |         7714 |             34.9 |              284.8 |
| 2016-08              |         7473 |             35.4 |              286.9 |
| 2016-09              |         7629 |             34.4 |              284   |
| 2016-10              |         7953 |             34.9 |              284.8 |
| 2016-11              |         7788 |             34.9 |              286   |
| 2016-12              |         7670 |             34.8 |              284.7 |
| 2017-01              |         7723 |             34.6 |              283.9 |
| 2017-02              |         6861 |             36   |              290.8 |
| 2017-03              |         8149 |             34.4 |              284.1 |
| 2017-04              |         7690 |             34.6 |              287.9 |
| 2017-05              |         7558 |             33.7 |              283.5 |
| 2017-06              |         7565 |             34.1 |              282.6 |
| 2017-07              |         7704 |             35.4 |              286.5 |
| 2017-08              |         7052 |             34.3 |              284.7 |
| 2017-09              |         7035 |             35.5 |              290.9 |
| 2017-10              |         7242 |             35   |              287.8 |
| 2017-11              |         7105 |             34.9 |              285   |
| 2017-12              |         6802 |             35.5 |              287.2 |
| 2018-01              |         7150 |             34.8 |              284.8 |
| 2018-02              |         6445 |             34.6 |              284.4 |
| 2018-03              |         5184 |             35.6 |              285.3 |


### 3. Demand by day of week and hour of day (heatmap source) ------------

| arrival_dow   |   arrival_dow_num | AE_Arrive_HourOfDay   |   admissions |
|:--------------|------------------:|:----------------------|-------------:|
| Monday        |                 0 | 01-04                 |         4880 |
| Monday        |                 0 | 05-08                 |         3978 |
| Monday        |                 0 | 09-12                 |        10933 |
| Monday        |                 0 | 13-16                 |        11116 |
| Monday        |                 0 | 17-20                 |        10923 |
| Monday        |                 0 | 21-24                 |         5754 |
| Tuesday       |                 1 | 01-04                 |         4822 |
| Tuesday       |                 1 | 05-08                 |         3975 |
| Tuesday       |                 1 | 09-12                 |        11074 |
| Tuesday       |                 1 | 13-16                 |        10888 |
| Tuesday       |                 1 | 17-20                 |        10817 |
| Tuesday       |                 1 | 21-24                 |         5913 |
| Wednesday     |                 2 | 01-04                 |         4794 |
| Wednesday     |                 2 | 05-08                 |         3857 |
| Wednesday     |                 2 | 09-12                 |        10973 |
| Wednesday     |                 2 | 13-16                 |        10823 |
| Wednesday     |                 2 | 17-20                 |        10788 |
| Wednesday     |                 2 | 21-24                 |         5660 |
| Thursday      |                 3 | 01-04                 |         4270 |
| Thursday      |                 3 | 05-08                 |         3421 |
| Thursday      |                 3 | 09-12                 |         9685 |
| Thursday      |                 3 | 13-16                 |         9714 |
| Thursday      |                 3 | 17-20                 |         9708 |
| Thursday      |                 3 | 21-24                 |         5095 |
| Friday        |                 4 | 01-04                 |         4396 |
| Friday        |                 4 | 05-08                 |         3408 |
| Friday        |                 4 | 09-12                 |         9665 |
| Friday        |                 4 | 13-16                 |         9715 |
| Friday        |                 4 | 17-20                 |         9481 |
| Friday        |                 4 | 21-24                 |         4920 |
| Saturday      |                 5 | 01-04                 |         5307 |
| Saturday      |                 5 | 05-08                 |         4303 |
| Saturday      |                 5 | 09-12                 |        12055 |
| Saturday      |                 5 | 13-16                 |        12214 |
| Saturday      |                 5 | 17-20                 |        11929 |
| Saturday      |                 5 | 21-24                 |         6380 |
| Sunday        |                 6 | 01-04                 |         4953 |
| Sunday        |                 6 | 05-08                 |         4137 |
| Sunday        |                 6 | 09-12                 |        11258 |
| Sunday        |                 6 | 13-16                 |        11380 |
| Sunday        |                 6 | 17-20                 |        11195 |
| Sunday        |                 6 | 21-24                 |         5887 |


### 4. Seasonality: admissions by calendar month across all years -------

|   arrival_month | arrival_month_name   |   admissions |   avg_ae_time_mins |
|----------------:|:---------------------|-------------:|-------------------:|
|               1 | Jan                  |        27169 |              284.2 |
|               2 | Feb                  |        25466 |              287.7 |
|               3 | Mar                  |        29483 |              286.1 |
|               4 | Apr                  |        26964 |              288   |
|               5 | May                  |        28062 |              285.5 |
|               6 | Jun                  |        27410 |              286.8 |
|               7 | Jul                  |        27433 |              285.8 |
|               8 | Aug                  |        26028 |              285.6 |
|               9 | Sep                  |        26673 |              286.8 |
|              10 | Oct                  |        27716 |              286   |
|              11 | Nov                  |        27535 |              285.4 |
|              12 | Dec                  |        26505 |              286.5 |


### 5. Breach rate and average AE time by age band ------------------------

| Age_Band   |   admissions |   avg_ae_time_mins |   pct_4hr_breach |   avg_los_days |
|:-----------|-------------:|-------------------:|-----------------:|---------------:|
| 1-17       |        41743 |              273.9 |             32.1 |           1.34 |
| 18-24      |        21626 |              277   |             32.7 |           1.62 |
| 25-44      |        75036 |              277   |             33.1 |           2.15 |
| 45-64      |        67092 |              285.3 |             34.6 |           3.78 |
| 65-84      |        77765 |              298.6 |             37.8 |           7.21 |
| 85+        |        43182 |              297.6 |             37.4 |           8.16 |


### 6. Arrival mode vs breach rate and resource burden --------------------

| arrival_mode_label              |   admissions |   avg_ae_time_mins |   pct_4hr_breach |   avg_resource_burden |
|:--------------------------------|-------------:|-------------------:|-----------------:|----------------------:|
| Ambulance                       |       159150 |              314.8 |             41.4 |                 10.76 |
| Other (walk-in / own transport) |       167068 |              259   |             28.9 |                 10.68 |
| Unknown                         |          226 |              236.2 |             14.6 |                 10.64 |


### 7. Top clinical chapters (ICD-10) by volume and average AE time -------

| icd10_chapter_desc   |   admissions |   avg_ae_time_mins |   pct_4hr_breach |
|:---------------------|-------------:|-------------------:|-----------------:|
| Other                |       160353 |              285.4 |             34.9 |
| Injury and poisoning |        43392 |              285.2 |             34.8 |
| Respiratory system   |        41701 |              288.5 |             35.5 |
| Digestive system     |        26974 |              282.5 |             33.8 |
| Genitourinary system |        26733 |              287.2 |             35.1 |
| Circulatory system   |        22668 |              293.5 |             36.5 |
| nan                  |         4623 |              283.1 |             33.9 |


### 8. Treatment function (specialty) workload ranking --------------------

| treatment_function_desc           |   admissions |   avg_los_days |
|:----------------------------------|-------------:|---------------:|
| Emergency Medicine Service        |       103487 |           1.93 |
| Other                             |        90355 |           6.84 |
| General Internal Medicine Service |        77389 |           5.81 |
| General Surgery Service           |        28910 |           4.08 |
| Paediatric Service                |        26280 |           1.27 |
| nan                               |           23 |         nan    |


### 9. Deprivation (IMD decile) vs breach rate and long-stay rate ---------

|   IMD_Decile_From_LSOA |   admissions |   pct_4hr_breach |   pct_long_stay |
|-----------------------:|-------------:|-----------------:|----------------:|
|                      1 |        42722 |             35.1 |            27.9 |
|                      2 |        97172 |             34.9 |            28.2 |
|                      3 |        84737 |             35.1 |            28   |
|                      4 |        42634 |             34.7 |            28.1 |
|                      5 |        19735 |             35.1 |            27.9 |
|                      6 |        10875 |             35.1 |            28.3 |
|                      7 |         8779 |             35.4 |            27.8 |
|                      8 |         8721 |             34.7 |            26.8 |
|                      9 |         7342 |             34.8 |            27.6 |
|                     10 |         3727 |             33.7 |            27.1 |


### 10. Investigation burden vs average AE time (drives 4-hr breach) ------

|   AE_Num_Investigations |   admissions |   avg_ae_time_mins |
|------------------------:|-------------:|-------------------:|
|                       0 |          264 |              226   |
|                       1 |        47364 |              246.9 |
|                       2 |        20398 |              241.4 |
|                       3 |        12929 |              269.1 |
|                       4 |        14665 |              278   |
|                       5 |        17317 |              284.9 |
|                       6 |        18729 |              299.1 |
|                       7 |        20785 |              302.8 |
|                       8 |        19230 |              321.3 |
|                       9 |        19020 |              328.5 |
|                      10 |       135743 |              294.2 |


### 11. Year-on-year admissions growth ------------------------------------

|   arrival_year |   admissions |   pct_change_yoy |
|---------------:|-------------:|-----------------:|
|           2014 |        55424 |            nan   |
|           2015 |        73599 |             32.8 |
|           2016 |        90156 |             22.5 |
|           2017 |        88486 |             -1.9 |
|           2018 |        18779 |            -78.8 |


### 12. Night-time (00:00-04:00) vs daytime breach comparison -------------

| time_period         |   admissions |   pct_4hr_breach |   avg_ae_time_mins |
|:--------------------|-------------:|-----------------:|-------------------:|
| Day (04:00-21:00)   |       253413 |             33.3 |              274.8 |
| Night (21:00-04:00) |        73031 |             40.8 |              325.7 |


### 13. Distance travelled vs breach outcome (access/equity lens) ---------

| distance_band   |   admissions |   pct_4hr_breach |
|:----------------|-------------:|-----------------:|
| 0-2 miles       |       110357 |             34.8 |
| 2-5 miles       |       137482 |             35.3 |
| 5-10 miles      |        60510 |             34.6 |
| 10+ miles       |        18095 |             35.2 |


### 14. Weekday vs weekend operational comparison --------------------------

| day_type   |   admissions |   avg_ae_time_mins |   pct_4hr_breach |
|:-----------|-------------:|-------------------:|-----------------:|
| Weekday    |       225446 |              286.1 |             35   |
| Weekend    |       100998 |              286.4 |             34.9 |


### 15. Admission method mix (planned vs emergency pathways) --------------

| admission_method_desc                           |   admissions |   pct_of_total |
|:------------------------------------------------|-------------:|---------------:|
| Emergency: Provider's ED or dent                |       313772 |           96.1 |
| Emergency: Other means                          |        10321 |            3.2 |
| Emergency: Bed bureau                           |          678 |            0.2 |
| Emergency: Consultant Clinic                    |          604 |            0.2 |
| Emergency: Mental Health Crisis Resolution Team |          308 |            0.1 |
| Emergency: Other emergency admission            |          258 |            0.1 |
| Emergency: General Practitioner                 |          228 |            0.1 |
| Emergency: Other's ED                           |          218 |            0.1 |
| Emergency: Hospital Transfer                    |           57 |            0   |

