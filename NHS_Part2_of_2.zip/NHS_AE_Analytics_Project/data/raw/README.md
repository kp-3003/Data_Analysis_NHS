# NHS A&E Admissions Analysis - Synthetic Data

**Generoso Roberto | Personal Project**

---

## The Problem

NHS A&E departments face persistent pressure on waiting times, admission rates, and resource allocation. Understanding *which patients stay longest*, *when demand peaks*, and *what factors drive length of stay* is foundational to improving operational planning.

This project analyses four years of A&E admission data from an NHS provider to identify the patient, clinical, and temporal factors most associated with extended A&E time and high investigation burden.

---

## The Dataset

The data source is the **NHS England A&E Synthetic Dataset** - a realistic but privacy-safe dataset generated as part of an NHS England pilot to enable data sharing without exposing real patient records. The dataset was publicly available via NHS England's open data platform.

The full dataset is approximately **4.29GB** and contains **65,836,575 rows**, covering A&E attendances across 200+ NHS providers from March 2014 to March 2018, including both admitted and non-admitted patients.

For this analysis, the focus was narrowed to:
- Admitted patients only (those with `Admitted_Flag = 1`)
- A single provider: the provider with the highest total number of admissions (which accounts for 326,444 rows)

This produced a manageable, analytically coherent subset while retaining the realistic properties of the full synthetic dataset.

---

## The Technical Challenge

At 4.29GB, the full dataset could not be loaded into memory using standard pandas on a consumer laptop. This was resolved using **Dask**, a parallel computing library that allows dataframe operations on files larger than available RAM by processing data in chunks.

The data extraction pipeline (`get_AnE_Provider_Admission_Data.ipynb`) documents this process:
1. Read the full 4.29GB CSV using `dask.dataframe` with explicit dtype specification
2. Filter to admitted patients across all providers
3. Identify the provider with the highest admission volume
4. Extract all records for that provider using `.compute()` to convert to pandas
5. Save the resulting subset as `AnE_Synthetic_Data_Provider_Admission.csv` for downstream analysis

---

## Variables

| Variable | Description |
|---|---|
| IMD_Decile_From_LSOA | Deprivation score. 1 = top 10% most deprived areas in England |
| Age_Band | Age group of the patient |
| Sex | Coded 1 and 2 |
| AE_Arrive_Date | Date of A&E arrival |
| AE_Arrive_HourOfDay | Hour interval of arrival |
| AE_Time_Mins | Total minutes spent in A&E |
| AE_HRG | Healthcare Resource Group code |
| AE_Num_Diagnoses | Number of diagnoses recorded in A&E |
| AE_Num_Investigations | Number of investigations performed |
| AE_Num_Treatments | Number of treatments performed |
| AE_Arrival_Mode | Mode of arrival (ambulance, self-referral, etc.) |
| Provider_Patient_Distance_Miles | Distance from patient origin to provider |
| Admission_Method | Method of admission |
| ICD10_Chapter_Code | ICD-10 disease chapter |
| Treatment_Function_Code | Clinical specialty under which patient was treated |
| Length_Of_Stay_Days | Days admitted following A&E attendance |

---

## Analysis

The full exploratory analysis is in `AandE_admission_EA.ipynb`. Key findings across three levels of analysis:

### Univariate

- A&E time is positively skewed: most patients stay around 240 minutes
- Admissions increase year-on-year from 2014 to 2018
- Demand is lowest in August and highest in March
- Saturdays have the highest weekly admission rate; Fridays the lowest
- Peak arrival hours are 9am to 8pm
- The majority of patients come from the most deprived areas (IMD decile 1)
- Nearly equal split between ambulance and private transport arrivals

### Bivariate

A&E time is positively associated with:
- Higher number of investigations
- Older age group
- Night-time arrivals
- Ambulance arrival mode
- Low healthcare resource needs (counter-intuitively - see multivariate findings)

A&E time is negatively associated with:
- Morning arrivals (9am to 12pm)
- GP referral admissions
- High healthcare resource needs
- Digestive system conditions
- General surgery and paediatric treatment functions

### Multivariate

- Number of investigations is the strongest predictor of A&E time: median time exceeds 240 minutes for patients undergoing 8 or more investigations
- Patients requiring high healthcare resources spend *less* time in A&E than those requiring low resources - likely reflecting faster clinical pathways for high-acuity cases
- Ambulance arrivals have the lowest minimum A&E time but the highest upper limit, reflecting the range of acuity in this group
- The combination of low healthcare resource need, older age, and ambulance arrival is associated with the longest A&E stays
- Arrival between 1am and 4am is the peak hour for stays exceeding 240 minutes

---

## Key Insight

**Low healthcare resource need combined with high investigation burden, older age, ambulance arrival, and night admission is the profile most associated with extended A&E stays.** This suggests that operational pressure is driven not primarily by high-acuity patients but by a volume of lower-acuity older patients who require extensive workup before a clinical decision can be made.

---

## Repository Structure

```
A-E_admitted_Synthetic_Data/
├── get_AnE_Provider_Admission_Data.ipynb       # Dask pipeline: extracts provider subset from 4.29GB dataset
├── AandE_admission_EA.ipynb                    # Full exploratory analysis notebook
├── AandE_admission_EA.html                     # Rendered HTML version of the analysis (open in browser)
├── AandE_admission_analysis_presentation.ipynb # Presentation notebook
├── A&E admission analysis presentation.pdf     # PDF export of findings presentation
├── AnE_Synthetic_Data_Provider_Admission.csv   # Extracted provider subset (analysis-ready)
├── dataset_for_analysis.csv                    # Final cleaned dataset
├── Admission_Method.csv                        # Reference table: admission method codes
├── ICD10chapters.csv                           # Reference table: ICD-10 chapter codes
├── Sex_Code.csv                                # Reference table: sex codes
├── Treatment_Function_Code.csv                 # Reference table: treatment function codes
└── README.md
```

The rendered HTML file (`AandE_admission_EA.html`) can be opened directly in a browser to view the full analysis including all charts without needing to run any code.

---

## Tools

| Tool | Purpose |
|---|---|
| Python | Primary analysis language |
| Dask | Reading and filtering the 4.29GB dataset without memory overflow |
| Pandas | Data wrangling and analysis on the extracted subset |
| Matplotlib / Seaborn | Visualisation |
| Jupyter Notebook | Analysis environment |

---

## Limitations

- Dataset is synthetic - generated to be statistically realistic but not derived from real patient records. Findings reflect plausible patterns but cannot be used for clinical or policy decisions
- Analysis is limited to a single, unidentified NHS provider. Results may not generalise across providers or regions
- The NHS England hosting page for this dataset is no longer active. The analysis was conducted when the data was publicly available
- Deprivation data (IMD) is at LSOA level and may not accurately reflect individual patient socioeconomic status

---

## About the Author

Generoso Roberto is a GMC-registered doctor and public health professional based in the UK, working at the intersection of digital health, data analytics, and health equity.

[LinkedIn](https://www.linkedin.com/in/generoso-roberto) | [GitHub](https://github.com/biogear13)
