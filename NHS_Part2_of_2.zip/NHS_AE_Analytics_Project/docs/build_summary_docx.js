const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, Table, TableRow, TableCell,
  WidthType, ShadingType, BorderStyle, AlignmentType, PageOrientation, Header, Footer,
  PageNumber, NumberFormat, LevelFormat, convertInchesToTwip
} = require("docx");
const fs = require("fs");

const NAVY = "003E74";
const TEAL = "009CBC";
const GOLD = "C0A96B";
const GREY = "6B7280";
const DARK = "1A2330";
const LIGHTBG = "F4F6F8";

const PAGE_W = 12240, PAGE_H = 15840; // US Letter DXA

function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 320, after: 140 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: GOLD, space: 4 } },
    children: [new TextRun({ text, bold: true, color: NAVY, size: 26 })],
  });
}
function h2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 220, after: 100 },
    children: [new TextRun({ text, bold: true, color: NAVY, size: 22 })],
  });
}
function body(text, opts = {}) {
  return new Paragraph({
    spacing: { after: 140, line: 276 },
    children: [new TextRun({ text, size: 21, color: DARK, ...opts })],
  });
}
function bullet(text, level = 0) {
  return new Paragraph({
    numbering: { reference: "bullets", level },
    spacing: { after: 80 },
    children: [new TextRun({ text, size: 21, color: DARK })],
  });
}
function kpiCell(label, value, width) {
  return new TableCell({
    width: { size: width, type: WidthType.DXA },
    shading: { type: ShadingType.CLEAR, fill: "FFFFFF" },
    margins: { top: 160, bottom: 160, left: 160, right: 160 },
    borders: {
      top: { style: BorderStyle.SINGLE, size: 4, color: "E2E6EA" },
      bottom: { style: BorderStyle.SINGLE, size: 4, color: "E2E6EA" },
      left: { style: BorderStyle.SINGLE, size: 4, color: "E2E6EA" },
      right: { style: BorderStyle.SINGLE, size: 4, color: "E2E6EA" },
    },
    children: [
      new Paragraph({ spacing: { after: 40 }, children: [new TextRun({ text: label, size: 16, color: GREY, bold: true })] }),
      new Paragraph({ children: [new TextRun({ text: value, size: 30, color: NAVY, bold: true })] }),
    ],
  });
}

function dataTable(headers, rows, widths) {
  const headerRow = new TableRow({
    tableHeader: true,
    children: headers.map((htext, i) => new TableCell({
      width: { size: widths[i], type: WidthType.DXA },
      shading: { type: ShadingType.CLEAR, fill: NAVY },
      margins: { top: 100, bottom: 100, left: 120, right: 120 },
      children: [new Paragraph({ children: [new TextRun({ text: htext, bold: true, color: "FFFFFF", size: 18 })] })],
    })),
  });
  const bodyRows = rows.map((r, ri) => new TableRow({
    children: r.map((cell, i) => new TableCell({
      width: { size: widths[i], type: WidthType.DXA },
      shading: { type: ShadingType.CLEAR, fill: ri % 2 === 0 ? "FFFFFF" : LIGHTBG },
      margins: { top: 90, bottom: 90, left: 120, right: 120 },
      children: [new Paragraph({ children: [new TextRun({ text: String(cell), size: 18, color: DARK })] })],
    })),
  }));
  return new Table({
    width: { size: widths.reduce((a, b) => a + b, 0), type: WidthType.DXA },
    columnWidths: widths,
    rows: [headerRow, ...bodyRows],
  });
}

const doc = new Document({
  numbering: {
    config: [{
      reference: "bullets",
      levels: [
        { level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: convertInchesToTwip(0.3), hanging: convertInchesToTwip(0.18) } } } },
        { level: 1, format: LevelFormat.BULLET, text: "\u2013", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: convertInchesToTwip(0.6), hanging: convertInchesToTwip(0.18) } } } },
      ],
    }],
  },
  sections: [{
    properties: {
      page: {
        size: { width: PAGE_W, height: PAGE_H },
        margin: { top: 1100, bottom: 1000, left: 1100, right: 1100 },
      },
    },
    headers: {
      default: new Header({
        children: [new Paragraph({
          border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: "E2E6EA", space: 6 } },
          children: [
            new TextRun({ text: "NHS A&E OPERATIONAL ANALYTICS", bold: true, color: NAVY, size: 16 }),
            new TextRun({ text: "   |   End-to-End Data Analytics Project", color: GREY, size: 16 }),
          ],
        })],
      }),
    },
    footers: {
      default: new Footer({
        children: [new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun({ text: "Page ", size: 16, color: GREY }),
            new TextRun({ children: [PageNumber.CURRENT], size: 16, color: GREY }),
            new TextRun({ text: " of ", size: 16, color: GREY }),
            new TextRun({ children: [PageNumber.TOTAL_PAGES], size: 16, color: GREY }),
          ],
        })],
      }),
    },
    children: [
      // Title block
      new Paragraph({ spacing: { after: 40 }, children: [new TextRun({ text: "PROJECT OVERVIEW", bold: true, color: GOLD, size: 18 })] }),
      new Paragraph({
        spacing: { after: 60 },
        children: [new TextRun({ text: "NHS A&E Operational Analytics", bold: true, color: NAVY, size: 44 })],
      }),
      new Paragraph({
        spacing: { after: 260 },
        children: [new TextRun({ text: "An end-to-end data analytics engagement built on NHS England open data — Python, SQL, statistical testing, and Power BI", color: GREY, size: 22, italics: true })],
      }),

      h1("Executive Summary"),
      body("This project demonstrates a complete, real-world data analytics workflow built on genuine NHS England Emergency Department data: from raw patient-level records through cleaning, exploratory analysis, formal statistical testing, a SQL analytics warehouse, and a Power BI-ready operational dashboard. The underlying dataset covers 326,444 admitted A&E patients at a single anonymised NHS acute provider between March 2014 and March 2018, drawn from NHS England's published synthetic A&E dataset — a realistic, privacy-safe extract designed for exactly this kind of analytical practice."),
      body("The headline finding: the provider's four-hour breach rate for admitted patients holds steady at approximately 35% across the full four-year period, well above the NHS's 95% national standard. Statistical testing confirms this is not noise — the 95% confidence interval for the true breach rate is narrow (34.8% to 35.2%), and the strongest driver of extended time in the department is the number of clinical investigations a patient requires, not age, arrival mode, or day of week, though all of these carry a statistically significant effect too."),

      h1("Business Context"),
      body("NHS Emergency Departments operate under sustained pressure: rising attendance volumes, an ageing population with more complex needs, and a national four-hour treatment standard that most trusts now struggle to meet. Operational and clinical leadership need answers to three practical questions:"),
      bullet("Where and when does demand concentrate, so staffing and capacity can be matched to it?"),
      bullet("What actually drives breaches of the four-hour standard — is it patient mix, clinical workup, or timing?"),
      bullet("Are some patient groups experiencing worse outcomes than others, and does that call for a targeted response?"),
      body("This project answers all three using a single, reproducible pipeline that a trust's analytics team could adapt to its own live data feed."),

      h1("Data Source"),
      body("Source: NHS England A&E Synthetic Dataset — an open, privacy-safe patient-level extract published by NHS England to support analytical training and tool development without exposing real patient records. This project uses the admitted-patient subset for a single anonymised provider (326,444 records), the largest single-provider slice of the original 65.8 million-row national release."),
      body("Fields cover patient demographics (age band, sex, deprivation decile), operational timing (arrival date, hour, time in department), clinical workload (diagnoses, investigations, treatments recorded), casemix (ICD-10 chapter, treatment specialty, admission method), and outcome (length of inpatient stay)."),

      h1("Methodology and Technical Stack"),
      h2("1. Data preparation — Python"),
      body("Raw records were loaded and cleaned in pandas: duplicate removal, implausible-duration filtering, missing-value handling, and enrichment with derived fields (four-hour breach flag, weekend flag, resource-burden score, fiscal year). The cleaning logic lives in scripts_prep.py and produces both the analysis-ready fact table and a set of dimension tables for downstream modelling."),
      h2("2. Exploratory data analysis and statistics — Python"),
      body("A fully executed Jupyter notebook (notebooks/nhs_ae_eda_and_statistics.ipynb) covers univariate and bivariate exploration, demand-pattern analysis (trend, seasonality, day-of-week/hour heatmaps), and six formal statistical tests: a Welch's t-test on arrival mode, a chi-square test of independence on age band versus breach, a Mann-Whitney U test on weekday versus weekend timing, a one-way ANOVA across specialties, a 95% confidence interval on the population breach rate, and a Spearman correlation matrix across operational drivers."),
      h2("3. SQL analytics warehouse"),
      body("The cleaned data is loaded into a star-schema SQLite warehouse (nhs_ae.db): one fact table (fact_ae_admissions) plus five dimension tables (date, ICD-10 chapter, admission method, treatment function, sex). Fifteen analytical queries covering KPIs, trend, seasonality, casemix, and equity questions are provided in sql/analysis_queries.sql, with results captured in sql/query_results.md."),
      h2("4. Power BI dashboard"),
      body("The same star schema is exported as Power BI-ready CSVs (powerbi/model/), with a full build guide (powerbi/README.md) covering table relationships, eleven DAX measures, and a three-page report design: Executive Overview, Demand and Flow, and Casemix and Equity. An interactive HTML preview (powerbi/dashboard_preview.html) reproduces the intended report layout and can be opened in any browser."),

      h1("Key Findings"),
      new Table({
        width: { size: 10040, type: WidthType.DXA },
        columnWidths: [3300, 2200, 4540],
        rows: [
          new TableRow({ tableHeader: true, children: [
            new TableCell({ width: { size: 3300, type: WidthType.DXA }, shading: { type: ShadingType.CLEAR, fill: NAVY }, margins: { top: 100, bottom: 100, left: 120, right: 120 }, children: [new Paragraph({ children: [new TextRun({ text: "Metric", bold: true, color: "FFFFFF", size: 18 })] })] }),
            new TableCell({ width: { size: 2200, type: WidthType.DXA }, shading: { type: ShadingType.CLEAR, fill: NAVY }, margins: { top: 100, bottom: 100, left: 120, right: 120 }, children: [new Paragraph({ children: [new TextRun({ text: "Value", bold: true, color: "FFFFFF", size: 18 })] })] }),
            new TableCell({ width: { size: 4540, type: WidthType.DXA }, shading: { type: ShadingType.CLEAR, fill: NAVY }, margins: { top: 100, bottom: 100, left: 120, right: 120 }, children: [new Paragraph({ children: [new TextRun({ text: "Interpretation", bold: true, color: "FFFFFF", size: 18 })] })] }),
          ] }),
          ...[
            ["Total admissions analysed", "326,444", "Four full fiscal years, one provider"],
            ["4-hour breach rate", "35.0%", "95% CI: 34.8%–35.2%; stable across the period, structurally above the 95% target"],
            ["Average time in A&E", "286 minutes", "Right-skewed distribution; median below mean, long tail of extended stays"],
            ["Average length of stay", "4.35 days", "Once admitted as an inpatient"],
            ["Strongest driver of AE time", "Investigation count", "Spearman r stronger than age, distance or deprivation decile"],
            ["Age band effect", "Significant (p < 0.001)", "65+ patients breach at ~37–38% vs ~32% for under-18s"],
            ["Arrival mode effect", "Significant (p < 0.001)", "Ambulance arrivals breach at 41.4% vs 28.9% for other arrivals"],
            ["Deprivation (IMD) effect", "Minimal", "Breach and long-stay rates are broadly flat across deciles 1–10"],
          ].map((row, ri) => new TableRow({ children: row.map((cell, i) => new TableCell({
            width: { size: [3300, 2200, 4540][i], type: WidthType.DXA },
            shading: { type: ShadingType.CLEAR, fill: ri % 2 === 0 ? "FFFFFF" : LIGHTBG },
            margins: { top: 90, bottom: 90, left: 120, right: 120 },
            children: [new Paragraph({ children: [new TextRun({ text: cell, size: 18, color: DARK, bold: i === 1 })] })],
          })) })),
        ],
      }),
      new Paragraph({ spacing: { before: 200 } }),

      h1("Recommendations"),
      bullet("Target investigation turnaround time first. Since investigation count is the strongest single driver of dwell time, point-of-care testing or faster lab/imaging turnaround would likely move the breach rate more than headcount changes alone."),
      bullet("Build an ambulance fast-track pathway for straightforward cases. Ambulance arrivals breach at nearly one and a half times the rate of self-presenting patients — not all of that gap reflects acuity, and some is addressable through triage design."),
      bullet("Treat the 65+ cohort as a distinct operational segment. Older patients combine the highest breach rate, the longest average AE time, and (from the wider literature) the highest re-attendance risk — a dedicated frailty pathway is a proportionate response."),
      bullet("Deprioritise deprivation-targeted A&E interventions in favour of upstream primary care access work. The near-flat relationship between IMD decile and A&E outcomes in this data suggests the equity gap, if one exists, sits earlier in the patient journey rather than inside the department."),
      bullet("Move this pipeline onto a live feed. The SQL warehouse and Power BI model are built to point at a scheduled data refresh rather than a static export — the natural next step is connecting them to the trust's live A&E system rather than a quarterly manual pull."),

      h1("Deliverables"),
      bullet("data/ — raw and cleaned data, including the star-schema fact and dimension CSVs"),
      bullet("notebooks/nhs_ae_eda_and_statistics.ipynb — full EDA and statistical testing, executed with all outputs and charts"),
      bullet("nhs_ae.db — SQLite analytics warehouse (star schema)"),
      bullet("sql/analysis_queries.sql and sql/query_results.md — fifteen business-question queries with results"),
      bullet("powerbi/README.md — data model, relationships, DAX measures, and three-page report design"),
      bullet("powerbi/dashboard_preview.html — interactive preview of the intended Power BI report"),

      h1("Limitations"),
      bullet("The dataset is synthetic — statistically realistic but not drawn from real patient records, so findings illustrate method and pattern rather than informing live clinical or policy decisions."),
      bullet("The analysis covers a single, anonymised provider and admitted patients only; results should not be generalised to non-admitted attendances or to other trusts without their own data."),
      bullet("NHS England no longer publishes this release at its original web address; the extract used here was retrieved from a citation-linked open mirror that preserves the same official data."),
    ],
  }],
});

Packer.toBuffer(doc).then((buf) => {
  fs.writeFileSync("NHS_AE_Project_Overview.docx", buf);
  console.log("Written NHS_AE_Project_Overview.docx");
});
