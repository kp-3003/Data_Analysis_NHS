# NHS A&E Operational Analytics — End-to-End Project

An end-to-end data analytics project built on real NHS England open data, covering Python data
cleaning and EDA, formal statistical testing, a SQL analytics warehouse, and a Power BI-ready
dashboard model.

## Data source

NHS England A&E Synthetic Dataset — an open, privacy-safe patient-level extract published by NHS
England for analytical training and tool development. This project uses the admitted-patient
subset for a single anonymised acute provider: 326,444 records, March 2014 to March 2018.
Retrieved via the public mirror at
https://github.com/biogear13/A-E_admitted_Synthetic_Data (original NHS England hosting page no
longer active).

## How the pieces fit together

```
raw NHS CSVs  --scripts_prep.py-->  cleaned fact + dimension tables (star schema)
                                          |
                     +--------------------+--------------------+
                     |                    |                    |
              nhs_ae.db (SQLite)   Jupyter notebook       powerbi/model/*.csv
              sql/*.sql queries    EDA + statistics        + powerbi/README.md
              sql/query_results.md                          + dashboard_preview.html
```

## Folder guide

| Path | Contents |
|---|---|
| `data/raw/` | Original NHS extract and lookup tables, as downloaded |
| `data/processed/` | Cleaned fact table and dimension tables (CSV) |
| `scripts_prep.py` | Cleaning, enrichment, and star-schema build script |
| `nhs_ae.db` | SQLite analytics warehouse |
| `sql/analysis_queries.sql` | Fifteen business-question SQL queries |
| `sql/query_results.md` | Query results, rendered as tables |
| `notebooks/nhs_ae_eda_and_statistics.ipynb` | Full EDA and statistical testing, executed |
| `notebooks/figures/` | Chart exports from the notebook |
| `powerbi/model/` | Star-schema CSVs ready for Power BI import |
| `powerbi/README.md` | Data model, relationships, DAX measures, report page design |
| `powerbi/dashboard_preview.html` | Interactive HTML preview of the intended Power BI report |
| `docs/NHS_AE_Project_Overview.docx` | Client-facing project overview and findings summary |

## Reproducing this project

```bash
python3 scripts_prep.py                 # clean data, build star schema + SQLite warehouse
jupyter nbconvert --to notebook --execute --inplace notebooks/nhs_ae_eda_and_statistics.ipynb
```

Then open `powerbi/model/*.csv` in Power BI Desktop and follow `powerbi/README.md`, or open
`powerbi/dashboard_preview.html` in a browser for an immediate preview.

## Headline result

Across four years and 326,444 admitted patients, the four-hour breach rate holds at 35.0%
(95% CI 34.8%-35.2%) — structurally above the NHS's 95% national standard. The strongest single
driver of time in the department is the number of clinical investigations performed, ahead of
age, arrival mode, or deprivation. Full findings and statistical tests are in the notebook and
in `docs/NHS_AE_Project_Overview.docx`.

## Limitations

This is synthetic, privacy-safe data — statistically realistic but not drawn from real patient
records. It is well suited to demonstrating method, tooling, and analytical reasoning; it should
not be used to inform live clinical or policy decisions. The analysis is scoped to admitted
patients at a single anonymised provider.
