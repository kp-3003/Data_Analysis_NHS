"""
NHS A&E Attendances - Data Preparation Pipeline
=================================================
Loads the raw NHS England A&E synthetic admissions extract, cleans it,
enriches it with derived time fields, and builds a star schema
(fact + dimension tables) ready for SQL analysis and Power BI import.

Source: NHS England A&E Synthetic Dataset (open, privacy-safe synthetic
data covering admitted A&E patients at a single anonymised NHS acute
provider, March 2014 - March 2018).
"""

import pandas as pd
import numpy as np
import sqlite3
import os

RAW = "data/raw"
PROC = "data/processed"
os.makedirs(PROC, exist_ok=True)

# ---------------------------------------------------------------------
# 1. Load raw extract
# ---------------------------------------------------------------------
df = pd.read_csv(os.path.join(RAW, "AnE_Synthetic_Data_Provider_Admission.csv"))
print("Raw shape:", df.shape)

# ---------------------------------------------------------------------
# 2. Clean / standardise
# ---------------------------------------------------------------------
df["AE_Arrive_Date"] = pd.to_datetime(df["AE_Arrive_Date"], errors="coerce")

# Strip whitespace on object columns
for c in df.select_dtypes(include="object").columns:
    df[c] = df[c].astype(str).str.strip()

# Drop exact duplicate rows
before = len(df)
df = df.drop_duplicates()
print(f"Dropped {before - len(df)} exact duplicate rows")

# Basic sanity filters: AE_Time_Mins should be non-negative and capped
# at a realistic ceiling (72 hours) to remove data-entry artefacts.
df = df[(df["AE_Time_Mins"] >= 0) & (df["AE_Time_Mins"] <= 72 * 60)]

# Drop rows with missing arrival date (can't be placed on a timeline)
df = df.dropna(subset=["AE_Arrive_Date"])

# Fill small amounts of missing distance with the provider median
if df["Provider_Patient_Distance_Miles"].isna().any():
    med = df["Provider_Patient_Distance_Miles"].median()
    df["Provider_Patient_Distance_Miles"] = df["Provider_Patient_Distance_Miles"].fillna(med)

print("Cleaned shape:", df.shape)

# ---------------------------------------------------------------------
# 3. Derived fields
# ---------------------------------------------------------------------
df["arrival_year"] = df["AE_Arrive_Date"].dt.year
df["arrival_month"] = df["AE_Arrive_Date"].dt.month
df["arrival_month_name"] = df["AE_Arrive_Date"].dt.strftime("%b")
df["arrival_year_month"] = df["AE_Arrive_Date"].dt.to_period("M").astype(str)
df["arrival_quarter"] = "Q" + df["AE_Arrive_Date"].dt.quarter.astype(str)
df["arrival_dow"] = df["AE_Arrive_Date"].dt.day_name()
df["arrival_dow_num"] = df["AE_Arrive_Date"].dt.dayofweek  # 0=Mon
df["is_weekend"] = df["arrival_dow_num"].isin([5, 6])

# NHS four-hour standard: breach flag (time in A&E > 240 minutes)
df["breach_4hr"] = df["AE_Time_Mins"] > 240

# Long-stay admission flag (>3 days as inpatient)
df["long_stay_flag"] = df["Length_Of_Stay_Days"] > 3

# Human-readable sex label
sex_map = {1: "Male", 2: "Female", 0: "Not Known", 9: "Not Specified"}
df["sex_label"] = df["Sex"].map(sex_map)

# Arrival mode label (1 = Ambulance, 2 = Other/Own transport per NHS coding)
mode_map = {1: "Ambulance", 2: "Other (walk-in / own transport)"}
df["arrival_mode_label"] = df["AE_Arrival_Mode"].map(mode_map).fillna("Unknown")

# Resource burden score used later for multivariate framing
df["resource_burden"] = (
    df["AE_Num_Diagnoses"] + df["AE_Num_Investigations"] + df["AE_Num_Treatments"]
)

# ---------------------------------------------------------------------
# 4. Attach lookup descriptions
# ---------------------------------------------------------------------
icd10 = pd.read_csv(os.path.join(RAW, "ICD10chapters.csv"))
icd10.columns = [c.strip() for c in icd10.columns]
icd10["Description"] = icd10["Description"].str.strip()

adm_method = pd.read_csv(os.path.join(RAW, "Admission_Method.csv"))
adm_method.columns = [c.strip() for c in adm_method.columns]
adm_method["Description"] = adm_method["Description"].str.strip()
# Admission_Method values in the fact table are integers/codes; align dtype
df["Admission_Method"] = df["Admission_Method"].astype(str)
adm_method["Admission_Method"] = adm_method["Admission_Method"].astype(str)

tfc = pd.read_csv(os.path.join(RAW, "Treatment_Function_Code.csv"))
tfc.columns = [c.strip() for c in tfc.columns]
tfc["Description"] = tfc["Description"].str.strip()
df["Treatment_Function_Code"] = df["Treatment_Function_Code"].astype(str)
tfc["Treatment_Function_Code"] = tfc["Treatment_Function_Code"].astype(str)

df = df.merge(icd10, on="ICD10_Chapter_Code", how="left").rename(
    columns={"Description": "icd10_chapter_desc"}
)
df = df.merge(adm_method, on="Admission_Method", how="left").rename(
    columns={"Description": "admission_method_desc"}
)
df = df.merge(tfc, on="Treatment_Function_Code", how="left").rename(
    columns={"Description": "treatment_function_desc"}
)

# ---------------------------------------------------------------------
# 5. Surrogate key + save cleaned fact table
# ---------------------------------------------------------------------
df.insert(0, "attendance_id", range(1, len(df) + 1))

fact_cols = [
    "attendance_id", "AE_Arrive_Date", "arrival_year", "arrival_month",
    "arrival_month_name", "arrival_year_month", "arrival_quarter",
    "arrival_dow", "arrival_dow_num", "is_weekend", "AE_Arrive_HourOfDay",
    "Age_Band", "Sex", "sex_label", "IMD_Decile_From_LSOA",
    "AE_Time_Mins", "breach_4hr", "AE_HRG", "AE_Num_Diagnoses",
    "AE_Num_Investigations", "AE_Num_Treatments", "resource_burden",
    "AE_Arrival_Mode", "arrival_mode_label", "Provider_Patient_Distance_Miles",
    "Admission_Method", "admission_method_desc", "ICD10_Chapter_Code",
    "icd10_chapter_desc", "Treatment_Function_Code", "treatment_function_desc",
    "Length_Of_Stay_Days", "long_stay_flag",
]
fact = df[fact_cols].rename(columns={"AE_Arrive_Date": "arrival_date"})
fact.to_csv(os.path.join(PROC, "fact_ae_admissions.csv"), index=False)
print("Saved fact table:", fact.shape)

# ---------------------------------------------------------------------
# 6. Dimension tables (for star schema / Power BI)
# ---------------------------------------------------------------------
dim_date = (
    fact[["arrival_date"]].drop_duplicates().sort_values("arrival_date").reset_index(drop=True)
)
dim_date["date_key"] = dim_date["arrival_date"].dt.strftime("%Y%m%d").astype(int)
dim_date["year"] = dim_date["arrival_date"].dt.year
dim_date["month"] = dim_date["arrival_date"].dt.month
dim_date["month_name"] = dim_date["arrival_date"].dt.strftime("%b")
dim_date["quarter"] = "Q" + dim_date["arrival_date"].dt.quarter.astype(str)
dim_date["day_of_week"] = dim_date["arrival_date"].dt.day_name()
dim_date["is_weekend"] = dim_date["arrival_date"].dt.dayofweek.isin([5, 6])
dim_date["fiscal_year"] = np.where(
    dim_date["arrival_date"].dt.month >= 4,
    dim_date["arrival_date"].dt.year.astype(str) + "-" + (dim_date["arrival_date"].dt.year + 1).astype(str).str[-2:],
    (dim_date["arrival_date"].dt.year - 1).astype(str) + "-" + dim_date["arrival_date"].dt.year.astype(str).str[-2:],
)
dim_date.to_csv(os.path.join(PROC, "dim_date.csv"), index=False)

dim_icd10 = icd10.rename(columns={"Description": "icd10_chapter_desc"})
dim_icd10.to_csv(os.path.join(PROC, "dim_icd10_chapter.csv"), index=False)

dim_admission_method = adm_method.rename(columns={"Description": "admission_method_desc"})
dim_admission_method.to_csv(os.path.join(PROC, "dim_admission_method.csv"), index=False)

dim_treatment_function = tfc.rename(columns={"Description": "treatment_function_desc"})
dim_treatment_function.to_csv(os.path.join(PROC, "dim_treatment_function.csv"), index=False)

dim_sex = pd.DataFrame({"Sex": [0, 1, 2, 9], "sex_label": ["Not Known", "Male", "Female", "Not Specified"]})
dim_sex.to_csv(os.path.join(PROC, "dim_sex.csv"), index=False)

print("Saved dimension tables.")

# ---------------------------------------------------------------------
# 7. Build SQLite warehouse
# ---------------------------------------------------------------------
db_path = "nhs_ae.db"
if os.path.exists(db_path):
    os.remove(db_path)
conn = sqlite3.connect(db_path)

fact.to_sql("fact_ae_admissions", conn, index=False)
dim_date.to_sql("dim_date", conn, index=False)
dim_icd10.to_sql("dim_icd10_chapter", conn, index=False)
dim_admission_method.to_sql("dim_admission_method", conn, index=False)
dim_treatment_function.to_sql("dim_treatment_function", conn, index=False)
dim_sex.to_sql("dim_sex", conn, index=False)

conn.execute("CREATE INDEX idx_fact_date ON fact_ae_admissions(arrival_date)")
conn.execute("CREATE INDEX idx_fact_ym ON fact_ae_admissions(arrival_year_month)")
conn.commit()
conn.close()
print("SQLite warehouse built at", db_path)

# Quick summary
print("\n--- Quick summary ---")
print("Date range:", fact["arrival_date"].min(), "to", fact["arrival_date"].max())
print("Total admissions:", len(fact))
print("4-hour breach rate: {:.1%}".format(fact["breach_4hr"].mean()))
print("Mean AE time (mins):", round(fact["AE_Time_Mins"].mean(), 1))
print("Mean length of stay (days):", round(fact["Length_Of_Stay_Days"].mean(), 2))
