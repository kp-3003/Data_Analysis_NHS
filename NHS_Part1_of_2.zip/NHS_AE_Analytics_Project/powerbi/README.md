# Power BI Build Guide — NHS A&E Operational Dashboard

This folder contains a Power BI-ready star schema exported from the cleaned SQL warehouse. It is
built to be opened directly in Power BI Desktop: import the CSVs in `model/`, set the relationships
below, add the DAX measures, then build the three report pages described at the end.

## 1. Files in `model/`

| File | Role | Grain |
|---|---|---|
| `fact_ae_admissions.csv` | Fact table | One row per admitted A&E patient (326,444 rows) |
| `dim_date.csv` | Date dimension | One row per calendar date in range |
| `dim_icd10_chapter.csv` | Diagnosis chapter lookup | One row per ICD-10 chapter |
| `dim_admission_method.csv` | Admission method lookup | One row per admission method code |
| `dim_treatment_function.csv` | Specialty lookup | One row per treatment function code |
| `dim_sex.csv` | Sex lookup | One row per sex code |

## 2. Data model — relationships

Import all six tables via **Get Data > Text/CSV**, then in Model view set:

| From (fact) | To (dimension) | Cardinality | Cross-filter |
|---|---|---|---|
| `fact_ae_admissions[arrival_date]` | `dim_date[arrival_date]` | Many-to-one | Single |
| `fact_ae_admissions[ICD10_Chapter_Code]` | `dim_icd10_chapter[ICD10_Chapter_Code]` | Many-to-one | Single |
| `fact_ae_admissions[Admission_Method]` | `dim_admission_method[Admission_Method]` | Many-to-one | Single |
| `fact_ae_admissions[Treatment_Function_Code]` | `dim_treatment_function[Treatment_Function_Code]` | Many-to-one | Single |
| `fact_ae_admissions[Sex]` | `dim_sex[Sex]` | Many-to-one | Single |

This is a standard single-fact star schema — every dimension connects only to the fact table, never
to each other, which keeps filter direction predictable and avoids the ambiguous-relationship
warnings that come from snowflaking.

The fact table already carries pre-joined description columns (`icd10_chapter_desc`,
`admission_method_desc`, `treatment_function_desc`) from the SQL layer, so the dimension tables are
optional in Power BI — include them if you want independent slicers that aren't limited to values
present in the fact table (e.g. a full ICD-10 chapter list even for chapters with zero admissions
in a filtered period).

Mark `dim_date` as a **Date Table** (Modeling > Mark as Date Table) so time intelligence functions
work correctly.

## 3. Core DAX measures

Create a dedicated measures table (New Table > name it `_Measures`, delete the placeholder column)
and add:

```dax
Total Admissions = COUNTROWS(fact_ae_admissions)

Avg AE Time (mins) = AVERAGE(fact_ae_admissions[AE_Time_Mins])

4hr Breaches = CALCULATE([Total Admissions], fact_ae_admissions[breach_4hr] = TRUE)

Pct 4hr Breach =
DIVIDE([4hr Breaches], [Total Admissions])

Avg Length of Stay (days) = AVERAGE(fact_ae_admissions[Length_Of_Stay_Days])

Long Stay Admissions = CALCULATE([Total Admissions], fact_ae_admissions[long_stay_flag] = TRUE)

Pct Long Stay = DIVIDE([Long Stay Admissions], [Total Admissions])

Pct Weekend Arrivals =
DIVIDE(
    CALCULATE([Total Admissions], fact_ae_admissions[is_weekend] = TRUE),
    [Total Admissions]
)

Avg Resource Burden = AVERAGE(fact_ae_admissions[resource_burden])

Admissions YoY % =
VAR CurrentYear = [Total Admissions]
VAR PriorYear =
    CALCULATE([Total Admissions], SAMEPERIODLASTYEAR(dim_date[arrival_date]))
RETURN
    DIVIDE(CurrentYear - PriorYear, PriorYear)

Admissions MoM =
VAR CurrentMonth = [Total Admissions]
VAR PriorMonth =
    CALCULATE([Total Admissions], DATEADD(dim_date[arrival_date], -1, MONTH))
RETURN
    CurrentMonth - PriorMonth

Breach Rate vs Standard =
[Pct 4hr Breach] - 0.05   -- gap against the 95% national four-hour standard

Ambulance Share =
DIVIDE(
    CALCULATE([Total Admissions], fact_ae_admissions[arrival_mode_label] = "Ambulance"),
    [Total Admissions]
)
```

Format `Pct 4hr Breach`, `Pct Long Stay`, `Pct Weekend Arrivals`, `Admissions YoY %` and
`Ambulance Share` as percentages; format `Breach Rate vs Standard` as a percentage with a
conditional colour (red if positive, i.e. worse than standard).

## 4. Suggested report pages

**Page 1 — Executive Overview**
KPI cards across the top: Total Admissions, Pct 4hr Breach (with the 95% target as a reference
line), Avg AE Time, Avg Length of Stay. Below: a monthly line chart of admissions with breach rate
on a secondary axis, and a matrix of top ICD-10 chapters by volume and breach rate. Slicers: fiscal
year, quarter.

**Page 2 — Demand and Flow**
A day-of-week x hour-of-day heat matrix (visual: matrix with conditional formatting, or a custom
heatmap visual) reproducing the pattern from the EDA notebook. A clustered bar of admissions by
calendar month across all years (seasonality). A scatter of investigations vs AE time. Slicers:
arrival mode, weekend/weekday.

**Page 3 — Casemix and Equity**
Breach rate and average AE time by age band (bar chart). Breach rate and long-stay rate by IMD
decile (bar chart, sorted 1 to 10) to surface any deprivation-linked access or outcome gap.
Specialty (treatment function) ranked table with admissions and average length of stay. Slicers:
specialty, admission method.

Use the brand palette already applied in the notebook figures for visual consistency across the
Python, SQL and Power BI outputs: Berkeley Navy `#003E74`, teal `#009CBC`, gold `#C0A96B`.

## 5. Refresh path

In a live deployment this model would point at the SQL warehouse (`nhs_ae.db` here, a proper SQL
Server / Synapse warehouse in production) via a scheduled Power BI Gateway refresh rather than
static CSV import — the CSVs in `model/` are a portable snapshot so the report can be rebuilt and
shared without a live database connection.
